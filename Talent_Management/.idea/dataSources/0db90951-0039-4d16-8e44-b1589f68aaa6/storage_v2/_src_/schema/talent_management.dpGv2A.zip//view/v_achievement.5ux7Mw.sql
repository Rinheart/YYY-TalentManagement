create view v_achievement as
select `talent_management`.`achievement`.`AchievementID`      AS `AchievementID`,
       `v_work_experience`.`WorkExperienceID`                 AS `WorkExperienceID`,
       `v_work_experience`.`TalentID`                         AS `TalentID`,
       `v_work_experience`.`Name`                             AS `Name`,
       `v_work_experience`.`EnterpriseID`                     AS `EnterpriseID`,
       `v_work_experience`.`EnterpriseName`                   AS `EnterpriseName`,
       `v_work_experience`.`DepartmentID`                     AS `DepartmentID`,
       `v_work_experience`.`DepartmentName`                   AS `DepartmentName`,
       `talent_management`.`achievement`.`Content`            AS `Content`,
       `talent_management`.`achievement`.`StartTime`          AS `StartTime`,
       `talent_management`.`achievement`.`EndTime`            AS `EndTime`,
       `talent_management`.`achievement`.`AchievementScore`   AS `AchievementScore`,
       `talent_management`.`achievement`.`AchievementComment` AS `AchievementComment`,
       `talent_management`.`achievement`.`Recorder`           AS `Recorder`,
       `talent_management`.`talent`.`Name`                    AS `RecorderName`,
       `talent_management`.`achievement`.`RecordTime`         AS `RecordTime`
from ((`talent_management`.`achievement` join `talent_management`.`v_work_experience`)
         join `talent_management`.`talent`)
where ((`talent_management`.`achievement`.`WorkExperienceID` = `v_work_experience`.`WorkExperienceID`) and
       (`talent_management`.`achievement`.`Recorder` = `talent_management`.`talent`.`TalentID`));

