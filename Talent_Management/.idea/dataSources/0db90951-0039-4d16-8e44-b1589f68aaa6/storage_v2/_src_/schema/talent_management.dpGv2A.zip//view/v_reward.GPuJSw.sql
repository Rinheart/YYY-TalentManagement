create view v_reward as
select `talent_management`.`reward`.`RewardID`     AS `RewardID`,
       `v_work_experience`.`WorkExperienceID`      AS `WorkExperienceID`,
       `v_work_experience`.`TalentID`              AS `TalentID`,
       `v_work_experience`.`Name`                  AS `Name`,
       `v_work_experience`.`EnterpriseID`          AS `EnterpriseID`,
       `v_work_experience`.`EnterpriseName`        AS `EnterpriseName`,
       `v_work_experience`.`DepartmentID`          AS `DepartmentID`,
       `v_work_experience`.`DepartmentName`        AS `DepartmentName`,
       `talent_management`.`reward`.`RewardName`   AS `RewardName`,
       `talent_management`.`reward`.`RewardResult` AS `RewardResult`,
       `talent_management`.`reward`.`Prize`        AS `Prize`,
       `talent_management`.`reward`.`Date`         AS `Date`,
       `talent_management`.`reward`.`Recorder`     AS `Recorder`,
       `talent_management`.`talent`.`Name`         AS `RecorderName`,
       `talent_management`.`reward`.`RecordTime`   AS `RecordTime`
from ((`talent_management`.`reward` join `talent_management`.`v_work_experience`)
         join `talent_management`.`talent`)
where ((`talent_management`.`reward`.`WorkExperienceID` = `v_work_experience`.`WorkExperienceID`) and
       (`v_work_experience`.`TalentID` = `talent_management`.`talent`.`TalentID`));

