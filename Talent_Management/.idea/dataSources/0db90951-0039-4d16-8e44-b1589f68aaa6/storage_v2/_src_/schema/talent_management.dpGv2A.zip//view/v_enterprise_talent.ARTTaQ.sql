create view v_enterprise_talent as
select `talent_management`.`talent`.`TalentID`              AS `TalentID`,
       `talent_management`.`talent`.`Name`                  AS `Name`,
       `talent_management`.`work_experience`.`EnterpriseID` AS `EnterpriseID`,
       `talent_management`.`talent`.`Identity`              AS `Identity`
from (`talent_management`.`talent`
         join `talent_management`.`work_experience`)
where ((`talent_management`.`talent`.`TalentID` = `talent_management`.`work_experience`.`TalentID`) and
       ((`talent_management`.`work_experience`.`EndTime` is null) or
        (sysdate() between `talent_management`.`work_experience`.`StartTime` and `talent_management`.`work_experience`.`EndTime`)) and
       (`talent_management`.`talent`.`Identity` = 2));

