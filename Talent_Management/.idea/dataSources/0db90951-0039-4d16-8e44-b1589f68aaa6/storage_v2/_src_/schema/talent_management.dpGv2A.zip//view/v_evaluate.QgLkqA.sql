create view v_evaluate as
select `talent_management`.`evaluate`.`EvaluateID`      AS `EvaluateID`,
       `v_work_experience`.`WorkExperienceID`           AS `WorkExperienceID`,
       `v_work_experience`.`TalentID`                   AS `TalentID`,
       `v_work_experience`.`Name`                       AS `Name`,
       `v_work_experience`.`EnterpriseID`               AS `EnterpriseID`,
       `v_work_experience`.`EnterpriseName`             AS `EnterpriseName`,
       `v_work_experience`.`DepartmentID`               AS `DepartmentID`,
       `v_work_experience`.`DepartmentName`             AS `DepartmentName`,
       `talent_management`.`evaluate`.`Valuator`        AS `Valuator`,
       `talent_management`.`talent`.`Name`              AS `ValuatorName`,
       `talent_management`.`evaluate`.`TotalScore`      AS `TotalScore`,
       `talent_management`.`evaluate`.`AbilityScore`    AS `AbilityScore`,
       `talent_management`.`evaluate`.`AbilityComment`  AS `AbilityComment`,
       `talent_management`.`evaluate`.`AttitudeScore`   AS `AttitudeScore`,
       `talent_management`.`evaluate`.`AttitudeComment` AS `AttitudeComment`,
       `talent_management`.`evaluate`.`Time`            AS `Time`
from ((`talent_management`.`evaluate` join `talent_management`.`v_work_experience`)
         join `talent_management`.`talent`)
where ((`talent_management`.`evaluate`.`WorkExperienceID` = `v_work_experience`.`WorkExperienceID`) and
       (`talent_management`.`evaluate`.`Valuator` = `talent_management`.`talent`.`TalentID`));

