create view v_attend as
select `talent_management`.`attend`.`AttendID`         AS `AttendID`,
       `talent_management`.`attend`.`WorkExperienceID` AS `WorkExperienceID`,
       `v_work_experience`.`TalentID`                  AS `TalentID`,
       `v_work_experience`.`Name`                      AS `Name`,
       `v_work_experience`.`EnterpriseID`              AS `EnterpriseID`,
       `v_work_experience`.`EnterpriseName`            AS `EnterpriseName`,
       `v_work_experience`.`DepartmentID`              AS `DepartmentID`,
       `v_work_experience`.`DepartmentName`            AS `DepartmentName`,
       `talent_management`.`attend`.`Event`            AS `Event`,
       `talent_management`.`attend`.`Date`             AS `Date`,
       `talent_management`.`attend`.`Recorder`         AS `Recorder`,
       `talent_management`.`talent`.`Name`             AS `RecorderName`,
       `talent_management`.`attend`.`RecordTime`       AS `RecordTime`
from ((`talent_management`.`attend` join `talent_management`.`v_work_experience`)
         join `talent_management`.`talent`)
where ((`talent_management`.`attend`.`WorkExperienceID` = `v_work_experience`.`WorkExperienceID`) and
       (`talent_management`.`attend`.`Recorder` = `talent_management`.`talent`.`TalentID`));

