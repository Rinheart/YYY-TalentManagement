create definer = root@localhost view v_big_event as
select `talent_management`.`big_event`.`BigEventID` AS `BigEventID`,
       `v_work_experience`.`WorkExperienceID`       AS `WorkExperienceID`,
       `v_work_experience`.`TalentID`               AS `TalentID`,
       `v_work_experience`.`Name`                   AS `Name`,
       `v_work_experience`.`EnterpriseID`           AS `EnterpriseID`,
       `v_work_experience`.`EnterpriseName`         AS `EnterpriseName`,
       `v_work_experience`.`DepartmentID`           AS `DepartmentID`,
       `v_work_experience`.`DepartmentName`         AS `DepartmentName`,
       `talent_management`.`big_event`.`Content`    AS `Content`,
       `talent_management`.`big_event`.`Date`       AS `Date`,
       `talent_management`.`big_event`.`Recorder`   AS `Recorder`,
       `talent_management`.`talent`.`Name`          AS `RecorderName`,
       `talent_management`.`big_event`.`RecordTime` AS `RecordTime`
from ((`talent_management`.`big_event` join `talent_management`.`v_work_experience`)
         join `talent_management`.`talent`)
where ((`talent_management`.`big_event`.`WorkExperienceID` = `v_work_experience`.`WorkExperienceID`) and
       (`v_work_experience`.`TalentID` = `talent_management`.`talent`.`TalentID`));

