create definer = root@localhost view v_work_experience as
select `talent_management`.`work_experience`.`WorkExperienceID` AS `WorkExperienceID`,
       `talent_management`.`talent`.`TalentID`                  AS `TalentID`,
       `talent_management`.`talent`.`Name`                      AS `Name`,
       `talent_management`.`enterprise`.`EnterpriseID`          AS `EnterpriseID`,
       `talent_management`.`enterprise`.`EnterpriseName`        AS `EnterpriseName`,
       `talent_management`.`department`.`DepartmentID`          AS `DepartmentID`,
       `talent_management`.`department`.`DepartmentName`        AS `DepartmentName`,
       `talent_management`.`work_experience`.`StartTime`        AS `StartTime`,
       `talent_management`.`work_experience`.`EndTime`          AS `EndTime`
from (((`talent_management`.`work_experience` join `talent_management`.`talent`) join `talent_management`.`enterprise`)
         join `talent_management`.`department`)
where ((`talent_management`.`work_experience`.`TalentID` = `talent_management`.`talent`.`TalentID`) and
       (`talent_management`.`work_experience`.`EnterpriseID` = `talent_management`.`enterprise`.`EnterpriseID`) and
       (`talent_management`.`work_experience`.`DepartmentID` = `talent_management`.`department`.`DepartmentID`));

