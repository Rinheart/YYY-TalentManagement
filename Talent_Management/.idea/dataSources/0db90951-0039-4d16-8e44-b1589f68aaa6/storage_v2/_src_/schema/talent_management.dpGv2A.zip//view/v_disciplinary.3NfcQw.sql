create view v_disciplinary as
select `talent_management`.`disciplinary`.`DisciplinaryID` AS `DisciplinaryID`,
       `v_work_experience`.`WorkExperienceID`              AS `WorkExperienceID`,
       `v_work_experience`.`TalentID`                      AS `TalentID`,
       `v_work_experience`.`Name`                          AS `Name`,
       `v_work_experience`.`EnterpriseID`                  AS `EnterpriseID`,
       `v_work_experience`.`EnterpriseName`                AS `EnterpriseName`,
       `v_work_experience`.`DepartmentID`                  AS `DepartmentID`,
       `v_work_experience`.`DepartmentName`                AS `DepartmentName`,
       `talent_management`.`disciplinary`.`Content`        AS `Content`,
       `talent_management`.`disciplinary`.`Date`           AS `Date`,
       `talent_management`.`disciplinary`.`Recorder`       AS `Recorder`,
       `talent_management`.`talent`.`Name`                 AS `RecorderName`,
       `talent_management`.`disciplinary`.`RecordTime`     AS `RecordTime`
from ((`talent_management`.`disciplinary` join `talent_management`.`v_work_experience`)
         join `talent_management`.`talent`)
where ((`talent_management`.`disciplinary`.`WorkExperienceID` = `v_work_experience`.`WorkExperienceID`) and
       (`v_work_experience`.`TalentID` = `talent_management`.`talent`.`TalentID`));

